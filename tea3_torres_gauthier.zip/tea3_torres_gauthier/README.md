# merge_et_quick_sort_c_TEA
 TEA3 : Quick sort et merge sort en C

Alexandre Torres--Leguet et Valentin Gauthier
